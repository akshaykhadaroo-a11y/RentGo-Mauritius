import { CalendarDays, MapPin, Search } from "lucide-react";
import Link from "next/link";

export default function BookingEnquiry() {
  return (
    <section className="booking-panel" aria-labelledby="booking-heading">
      <div className="booking-heading">
        <span className="eyebrow">Start your journey</span>
        <h2 id="booking-heading">Find the right car for your trip</h2>
        <p>Choose your dates and location, then browse the fleet. We’ll confirm availability with you on WhatsApp.</p>
      </div>
      <form action="/cars" className="booking-form">
        <label>
          <span><CalendarDays size={16} /> Pickup date</span>
          <input name="pickup" type="date" required />
        </label>
        <label>
          <span><CalendarDays size={16} /> Return date</span>
          <input name="return" type="date" required />
        </label>
        <label>
          <span><MapPin size={16} /> Pickup location</span>
          <select name="location" defaultValue="Airport">
            <option>Airport</option>
            <option>Hotel or accommodation</option>
            <option>Port Louis</option>
            <option>Grand Baie</option>
            <option>Flic en Flac</option>
            <option>Other location</option>
          </select>
        </label>
        <button className="button button-primary" type="submit"><Search size={17} /> Browse cars</button>
      </form>
      <p className="booking-note">Your enquiry is not a confirmed booking. Availability and final prices are confirmed directly.</p>
    </section>
  );
}
