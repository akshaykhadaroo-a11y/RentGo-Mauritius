import Link from "next/link";
import { CarFront, Menu, MessageCircle } from "lucide-react";
import { siteConfig } from "@/lib/config";
import { whatsappUrl } from "@/lib/whatsapp";

export default function Header() {
  return (
    <header className="site-header">
      <div className="container nav-wrap">
        <Link href="/" className="brand" aria-label="RentGo Mauritius home">
          <span className="brand-mark"><CarFront size={24} /></span>
          <span>RentGo <b>Mauritius</b></span>
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          <Link href="/">Home</Link>
          <Link href="/cars">Our cars</Link>
          <Link href="/locations">Locations</Link>
          <Link href="/#contact">Contact</Link>
        </nav>
        <a className="button button-small button-primary nav-cta" href={whatsappUrl()} target="_blank" rel="noopener noreferrer">
          <MessageCircle size={16} /> WhatsApp us
        </a>
        <details className="mobile-menu">
          <summary aria-label="Open navigation"><Menu size={24} /></summary>
          <nav aria-label="Mobile navigation">
            <Link href="/">Home</Link>
            <Link href="/cars">Our cars</Link>
            <Link href="/locations">Locations</Link>
            <Link href="/#contact">Contact</Link>
          </nav>
        </details>
      </div>
    </header>
  );
}
