import Link from "next/link";
import { Users, Gauge, Fuel, BriefcaseBusiness, ArrowUpRight } from "lucide-react";
import type { Car } from "@/lib/cars";
import WhatsAppLink from "@/components/WhatsAppLink";

export default function CarCard({ car }: { car: Car }) {
  return (
    <article className="car-card">
      <Link href={`/cars/${car.slug}`} className="car-image-wrap" aria-label={`View ${car.name}`}>
        {/* External sample images are used until the owner uploads real fleet photos. */}
        <img className="car-image" src={car.image} alt={`${car.name} sample vehicle`} loading="lazy" />
        <span className="car-category">{car.category}</span>
        <span className="image-arrow"><ArrowUpRight size={18} /></span>
      </Link>
      <div className="car-card-body">
        <div className="car-title-row">
          <div>
            <h3><Link href={`/cars/${car.slug}`}>{car.name}</Link></h3>
            <p className="muted">Indicative sample price</p>
          </div>
          <div className="price"><strong>{car.pricePerDay.toLocaleString("en-MU")}</strong><span>MUR / day</span></div>
        </div>
        <div className="car-specs">
          <span><Users size={16} /> {car.seats} seats</span>
          <span><Gauge size={16} /> {car.transmission}</span>
          <span><Fuel size={16} /> {car.fuel}</span>
          <span><BriefcaseBusiness size={16} /> {car.luggage} bags</span>
        </div>
        <WhatsAppLink carName={car.name} label="Ask about this car" className="button-full" />
      </div>
    </article>
  );
}
