import { MessageCircle } from "lucide-react";
import { whatsappUrl } from "@/lib/whatsapp";

type Props = {
  label?: string;
  carName?: string;
  className?: string;
};

export default function WhatsAppLink({
  label = "Enquire on WhatsApp",
  carName,
  className = "",
}: Props) {
  return (
    <a
      className={`button button-whatsapp ${className}`}
      href={whatsappUrl({ carName })}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`${label}${carName ? ` about ${carName}` : ""}`}
    >
      <MessageCircle size={18} aria-hidden="true" />
      {label}
    </a>
  );
}
