import Link from "next/link";
import { MapPin, MessageCircle } from "lucide-react";
import { siteConfig } from "@/lib/config";
import { whatsappUrl } from "@/lib/whatsapp";

export default function Footer() {
  return (
    <footer className="site-footer" id="contact">
      <div className="container footer-grid">
        <div>
          <Link href="/" className="brand footer-brand">
            <span className="brand-mark"><MapPin size={22} /></span>
            <span>RentGo <b>Mauritius</b></span>
          </Link>
          <p className="footer-copy">Your island journey starts here. Enquire directly with our team and confirm the details before travelling.</p>
        </div>
        <div>
          <h3>Explore</h3>
          <Link href="/cars">Our cars</Link>
          <Link href="/locations">Delivery locations</Link>
          <Link href="/terms">Rental terms</Link>
        </div>
        <div>
          <h3>Get in touch</h3>
          <p>Mauritius</p>
          <a href={whatsappUrl()} target="_blank" rel="noopener noreferrer"><MessageCircle size={16} /> +230 5978 1302</a>
          <p className="small-note">Sample website: please verify business details and rental terms before launch.</p>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} {siteConfig.name}</span>
        <span>Made for exploring Mauritius</span>
      </div>
    </footer>
  );
}
