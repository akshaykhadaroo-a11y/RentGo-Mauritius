export type Car = {
  slug: string;
  name: string;
  category: string;
  pricePerDay: number;
  seats: number;
  transmission: "Automatic" | "Manual";
  fuel: string;
  luggage: number;
  image: string;
  description: string;
  featured?: boolean;
  sample?: boolean;
};

export const cars: Car[] = [
  {
    slug: "compact-hatchback",
    name: "Compact Hatchback",
    category: "Economy",
    pricePerDay: 1200,
    seats: 5,
    transmission: "Automatic",
    fuel: "Petrol",
    luggage: 2,
    image: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=85,
    description: "A practical city-friendly option for exploring the island.",
    featured: true,
    sample: true,
  },
  {
    slug: "city-compact",
    name: "City Compact",
    category: "Economy",
    pricePerDay: 1400,
    seats: 5,
    transmission: "Manual",
    fuel: "Petrol",
    luggage: 2,
    image: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1200&q=85",
    description: "Easy to park and comfortable for everyday island journeys.",
    featured: true,
    sample: true,
  },
  {
    slug: "family-sedan",
    name: "Family Sedan",
    category: "Comfort",
    pricePerDay: 1800,
    seats: 5,
    transmission: "Automatic",
    fuel: "Petrol",
    luggage: 3,
    image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=85",
    description: "A comfortable choice for couples, families and longer drives.",
    featured: true,
    sample: true,
  },
  {
    slug: "island-suv",
    name: "Island SUV",
    category: "SUV",
    pricePerDay: 2500,
    seats: 5,
    transmission: "Automatic",
    fuel: "Petrol",
    luggage: 4,
    image: "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=1200&q=85",
    description: "Extra space for luggage and day trips around Mauritius.",
    featured: true,
    sample: true,
  },
];
