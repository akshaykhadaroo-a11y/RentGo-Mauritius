import { siteConfig } from "@/lib/config";

type Enquiry = {
  carName?: string;
  name?: string;
  pickupDate?: string;
  returnDate?: string;
  pickupLocation?: string;
  message?: string;
};

export function whatsappUrl(enquiry: Enquiry = {}) {
  const lines = [
    `Hello ${siteConfig.name}, I would like to enquire about a car rental.`,
    enquiry.carName ? `Vehicle: ${enquiry.carName}` : "",
    enquiry.name ? `Name: ${enquiry.name}` : "",
    enquiry.pickupDate ? `Pickup date: ${enquiry.pickupDate}` : "",
    enquiry.returnDate ? `Return date: ${enquiry.returnDate}` : "",
    enquiry.pickupLocation ? `Pickup location: ${enquiry.pickupLocation}` : "",
    enquiry.message ? `Message: ${enquiry.message}` : "",
    "Please confirm availability and the final price.",
  ].filter(Boolean);
  return `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(lines.join("\n"))}`;
}
