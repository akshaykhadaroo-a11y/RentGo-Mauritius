export const siteConfig = {
  name: "RentGo Mauritius",
  tagline: "Discover Mauritius. Drive Your Way.",
  whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "23059781302",
  currency: "MUR",
  description:
    "Explore Mauritius at your own pace with RentGo Mauritius. Browse our sample fleet and enquire directly on WhatsApp.",
};
