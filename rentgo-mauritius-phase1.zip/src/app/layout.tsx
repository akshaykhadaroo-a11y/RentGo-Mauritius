import type { Metadata, Viewport } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { siteConfig } from "@/lib/config";

export const metadata: Metadata = {
  title: { default: "RentGo Mauritius | Car Rental in Mauritius", template: "%s | RentGo Mauritius" },
  description: siteConfig.description,
  metadataBase: new URL("https://example.com"),
  openGraph: {
    title: "RentGo Mauritius | Car Rental in Mauritius",
    description: siteConfig.description,
    type: "website",
    locale: "en_MU",
  },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#146b58" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
