import Link from "next/link";
import { ArrowRight, BadgeCheck, CarFront, Headset, MapPinned, ShieldCheck, Sparkles, Plane, Clock3 } from "lucide-react";
import CarCard from "@/components/CarCard";
import BookingEnquiry from "@/components/BookingEnquiry";
import WhatsAppLink from "@/components/WhatsAppLink";
import { cars } from "@/lib/cars";

export default function HomePage() {
  const featured = cars.filter((car) => car.featured);
  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <span className="eyebrow"><span className="eyebrow-dot" /> Your island, your journey</span>
            <h1>Discover Mauritius.<br /><em>Drive Your Way.</em></h1>
            <p className="hero-copy">Find a car that fits your island plans. Explore Mauritius at your own pace, with friendly assistance just a WhatsApp message away.</p>
            <div className="hero-actions">
              <Link className="button button-primary" href="/cars">Explore our cars <ArrowRight size={17} /></Link>
              <WhatsAppLink label="Chat with us" />
            </div>
            <div className="hero-trust">
              <span><BadgeCheck size={16} /> Personal assistance</span>
              <span><MapPinned size={16} /> Island exploration</span>
              <span><ShieldCheck size={16} /> Clear enquiries</span>
            </div>
          </div>
          <div className="hero-visual">
            <img className="hero-photo" src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1400&q=90" alt="Tropical coastal landscape to inspire a Mauritius road trip" />
            <div className="floating-note">
              <span className="floating-note-icon"><CarFront size={21} /></span>
              <span><strong>Your island adventure</strong><small>Starts with the right ride</small></span>
            </div>
            <div className="hero-photo-label"><strong>Make more of Mauritius</strong><span>Coastlines, villages and hidden corners</span></div>
          </div>
        </div>
      </section>

      <div className="container booking-section"><BookingEnquiry /></div>

      <section className="section">
        <div className="container">
          <div className="section-top">
            <div><span className="eyebrow">Find your ride</span><h2>A car for every kind of getaway</h2><p className="section-intro">From compact city cars to roomier SUVs, explore our sample fleet and tell us what suits your trip.</p></div>
            <Link className="text-link" href="/cars">View all cars <ArrowRight size={15} style={{display:"inline", verticalAlign:"middle"}} /></Link>
          </div>
          <div className="car-grid">{featured.map((car) => <CarCard key={car.slug} car={car} />)}</div>
          <p className="small-note" style={{marginTop:18,color:"var(--muted)"}}>Please note: vehicles and prices shown are sample placeholders, not confirmed RentGo inventory or offers.</p>
        </div>
      </section>

      <section className="section section-soft">
        <div className="container">
          <div className="section-top"><div><span className="eyebrow">A smoother way to explore</span><h2>Made for your Mauritius trip</h2><p className="section-intro">We aim to make the enquiry process simple, clear and personal from the first message.</p></div></div>
          <div className="features-grid">
            <article className="feature"><span className="feature-icon"><Headset size={22} /></span><h3>Personal assistance</h3><p>Speak directly with the team on WhatsApp to discuss dates, vehicle options and your questions.</p></article>
            <article className="feature"><span className="feature-icon"><ShieldCheck size={22} /></span><h3>Clear details before you book</h3><p>Ask us to confirm the final price, deposit, insurance, mileage and rental conditions before agreeing.</p></article>
            <article className="feature"><span className="feature-icon"><MapPinned size={22} /></span><h3>Explore at your pace</h3><p>Plan your own island route, from coastal drives to local markets and scenic viewpoints.</p></article>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container location-banner">
          <div>
            <span className="eyebrow"><Plane size={15} /> Pick-up planning</span>
            <h2>Arriving in Mauritius?</h2>
            <p>Ask about your preferred pickup point, including the airport or your accommodation. We will confirm whether delivery is available for your dates before your rental is agreed.</p>
            <Link href="/locations" className="button button-primary">Explore locations <ArrowRight size={16} /></Link>
          </div>
          <img className="location-image" src="https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1200&q=85" alt="Turquoise ocean and tropical shoreline" loading="lazy" />
        </div>
      </section>

      <section className="section section-soft">
        <div className="container">
          <div className="section-top"><div><span className="eyebrow">Good to know</span><h2>Frequently asked questions</h2><p className="section-intro">A few helpful things to check before enquiring about your rental.</p></div></div>
          <div className="faq-list">
            <details><summary>How do I book a car?</summary><p>Choose a vehicle and send an enquiry through WhatsApp. Your rental is not confirmed until the team confirms availability and the terms with you.</p></details>
            <details><summary>Are the prices on this website final?</summary><p>No. The displayed cars and prices are sample placeholders for the website build. Replace them with your real fleet and confirmed rates before launch.</p></details>
            <details><summary>Can I request airport pickup?</summary><p>You can ask about airport pickup through WhatsApp. The exact pickup point, delivery availability and any fee must be confirmed with the team.</p></details>
            <details><summary>What documents do I need?</summary><p>Requirements can vary. Ask the team to confirm accepted driving licences, minimum age, deposit and insurance conditions before booking.</p></details>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container cta-band">
          <div><h2>Ready to explore the island?</h2><p>Tell us your dates and what kind of car you need. We’ll help you with the next steps.</p></div>
          <WhatsAppLink label="Enquire on WhatsApp" />
        </div>
      </section>
    </>
  );
}
