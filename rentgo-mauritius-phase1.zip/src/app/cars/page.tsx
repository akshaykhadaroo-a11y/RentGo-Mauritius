import type { Metadata } from "next";
import CarCard from "@/components/CarCard";
import { cars } from "@/lib/cars";

export const metadata: Metadata = { title: "Our Cars", description: "Explore the RentGo Mauritius sample car fleet and enquire on WhatsApp." };

export default async function CarsPage({ searchParams }: { searchParams: Promise<{ pickup?: string; return?: string; location?: string }> }) {
  const params = await searchParams;
  return (
    <>
      <section className="page-hero"><div className="container page-heading"><span className="eyebrow">Our fleet</span><h1>Find your island ride</h1><p>Explore the sample fleet below. Select a car to view its details and send us your enquiry on WhatsApp.</p>{params.pickup && <p><strong>Requested pickup:</strong> {params.pickup} · <strong>Return:</strong> {params.return || "Not selected"} · <strong>Location:</strong> {params.location || "Not selected"}</p>}</div></section>
      <section className="page-content"><div className="container"><div className="car-grid">{cars.map((car) => <CarCard key={car.slug} car={car} />)}</div><p className="notice" style={{marginTop:24}}>Demo fleet: all vehicle names, specifications and prices are placeholders. Contact RentGo to confirm actual vehicles, availability and final rates.</p></div></section>
    </>
  );
}
