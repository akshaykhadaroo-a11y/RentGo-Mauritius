import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Users, Gauge, Fuel, BriefcaseBusiness } from "lucide-react";
import { cars } from "@/lib/cars";
import WhatsAppLink from "@/components/WhatsAppLink";

export function generateStaticParams() { return cars.map((car) => ({ slug: car.slug })); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const car = cars.find((item) => item.slug === slug);
  return { title: car ? car.name : "Car not found", description: car ? `View details for ${car.name} and enquire with RentGo Mauritius on WhatsApp.` : "Vehicle not found." };
}
export default async function CarDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const car = cars.find((item) => item.slug === slug);
  if (!car) notFound();
  return (
    <section className="page-content"><div className="container">
      <p style={{marginTop:0,marginBottom:24}}><Link href="/cars" className="text-link"><ArrowLeft size={15} style={{display:"inline",verticalAlign:"middle"}} /> Back to all cars</Link></p>
      <div className="car-detail-grid">
        <div><img className="detail-image" src={car.image} alt={`${car.name} sample vehicle`} /><p className="muted" style={{marginTop:12}}>Sample vehicle image — replace with an actual fleet photo before launch.</p></div>
        <div className="detail-panel"><span className="eyebrow">{car.category} · Sample listing</span><h1>{car.name}</h1><p>{car.description}</p><div className="detail-price">{car.pricePerDay.toLocaleString("en-MU")} MUR <small>/ day · indicative sample price</small></div>
          <div className="detail-specs"><span><Users size={16} /> {car.seats} seats</span><span><Gauge size={16} /> {car.transmission}</span><span><Fuel size={16} /> {car.fuel}</span><span><BriefcaseBusiness size={16} /> {car.luggage} bags</span></div>
          <p className="notice">This is sample data, not a confirmed offer. Ask us to confirm the actual vehicle, dates, final price, insurance, deposit and rental terms.</p>
          <div style={{marginTop:20}}><WhatsAppLink carName={car.name} label="Enquire about this car" className="button-full" /></div>
        </div>
      </div>
    </div></section>
  );
}
