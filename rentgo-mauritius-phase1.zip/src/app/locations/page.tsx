import type { Metadata } from "next";
import { Plane, Hotel, MapPin } from "lucide-react";
import WhatsAppLink from "@/components/WhatsAppLink";
export const metadata: Metadata = { title: "Pickup & Delivery Locations", description: "Ask RentGo Mauritius about car rental pickup and delivery locations." };
const locations = [
  { icon: Plane, title: "Mauritius Airport", copy: "Travelling in by air? Ask about pickup arrangements, meeting points and any applicable delivery charges." },
  { icon: Hotel, title: "Hotel or accommodation", copy: "Share the name of your hotel or accommodation and ask whether delivery can be arranged for your dates." },
  { icon: MapPin, title: "Other locations", copy: "Tell us your preferred pickup point around Mauritius. We'll confirm feasibility and any extra fees before booking." },
];
export default function LocationsPage() {
  return <><section className="page-hero"><div className="container page-heading"><span className="eyebrow">Pickup planning</span><h1>Start your journey where it suits you</h1><p>Ask about pickup and delivery options before confirming your rental. Location coverage, timing and any charges must be confirmed directly.</p></div></section><section className="page-content"><div className="container"><div className="location-cards">{locations.map(({icon: Icon,title,copy})=><article className="location-card" key={title}><Icon size={24}/><h3>{title}</h3><p>{copy}</p></article>)}</div><div style={{marginTop:30}}><WhatsAppLink label="Ask about pickup locations"/></div></div></section></>;
}
