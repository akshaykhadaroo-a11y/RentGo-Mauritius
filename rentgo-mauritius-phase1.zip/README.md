# RentGo Mauritius

A Phase 1 starter website for a Mauritius car rental business, built with Next.js App Router, TypeScript and Tailwind CSS.

## Important before launch

- Car names, photos, specifications and MUR prices are sample placeholders.
- Confirm all rental policies and service claims before publishing.
- WhatsApp is configured to `23059781302`; verify this number and the click-to-chat link before launch.
- The metadata base URL is `https://example.com` and must be changed to the real domain.
- This phase has no database or admin dashboard yet. Fleet data is in `src/lib/cars.ts`.

## Run locally

Requires a compatible Node.js LTS version and npm.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open the local URL printed by Next.js.

## Build for production

```bash
npm run build
npm start
```

## Edit the fleet

Edit `src/lib/cars.ts`. Replace sample vehicle details, pricing and image URLs with verified business information and licensed/owned vehicle photos.

## WhatsApp number

Set `NEXT_PUBLIC_WHATSAPP_NUMBER` in `.env.local` to digits only, including the country code and without `+` or spaces. Current value: `23059781302`.

## GitHub workflow

1. Create a private repository named `rentgo-mauritius`.
2. Upload or push this project to that repository.
3. Keep `.env.local` and all secrets out of Git.
4. Commit changes in small increments.

## Next phases

- Phase 2: secure Supabase authentication, database and private admin dashboard.
- Phase 3: deployment on a Hostinger plan that explicitly supports the selected Next.js/Node.js application setup.
- Phase 4: custom domain, real fleet content, final SEO and launch testing.

## Notes

This project is a starting point and has not been deployed or connected to external services. Test the production build and verify all external image URLs in your chosen environment before launch.
